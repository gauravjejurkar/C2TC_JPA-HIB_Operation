package com.tns.placementManagementSystem.clients;

import com.tns.placementManagementSystem.entities.College;
import com.tns.placementManagementSystem.entities.Placement;
import com.tns.placementManagementSystem.entities.Student;
import com.tns.placementManagementSystem.entities.User;
import com.tns.placementManagementSystem.service.CollegeServiceImp;
import com.tns.placementManagementSystem.service.ICollegeService;
import com.tns.placementManagementSystem.service.IPlacementService;
import com.tns.placementManagementSystem.service.IStudentService;
import com.tns.placementManagementSystem.service.IUserService;
import com.tns.placementManagementSystem.service.PlacementServiceImp;
import com.tns.placementManagementSystem.service.StudentServiceImp;
import com.tns.placementManagementSystem.service.UserServiceImp;

public class PlacementManagementSystemUpdateAppTest {
	

	public static void main(String[] args) {
		
		IStudentService studentService = new StudentServiceImp();
		ICollegeService collegeService = new CollegeServiceImp();
		IPlacementService placeService = new PlacementServiceImp();
		IUserService userService       = new UserServiceImp();
		
//		Student student = new Student();
//		
//		student = studentService.searchStudentById(1);
//		student.setName("Aditya Shetty");
//		student.setQualification("BE");
//		studentService.updateStudent(student);
		
		
//		College college = new College();
//		
//		college = collegeService.findCollegeById(1L);
//		college.setLocation(null);
//		college.setCollegeName(null);
//		collegeService.updateCollege(college);
//		
//		Placement placement = new Placement();
//		
//		placement = placeService.searchPlacement(0);
//		placement.setpData(null);
//		placement.setpName(null);
//		placeService.updatePlacement(placement);
//		
//		
//		User user = new User();
//		
//		user = userService.findUserById(null);
//		user.setuName(null);
//		user.setuPassword(null);
//		userService.updateUser(user);
		
		
		
		
		
		
		
		
		
		

	}

}
